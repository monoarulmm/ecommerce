// product
Route::get('/product', $controller_path . '\Pages\productController@product_page');
Route::post('/add_product', $controller_path . '\Pages\productController@add_product');
Route::get('/product_list',$controller_path . '\Pages\productController@show_product');
Route::get('/delete_product/{id}',$controller_path . '\Pages\productController@delete_product');
Route::get('/update_product/{id}',$controller_path . '\Pages\productController@update_product');
Route::post('/update_product_confirm/{id}',$controller_path . '\Pages\productController@update_product_confirm');
Route::get('/my_product',$controller_path . '\Pages\productController@my_product');
Route::get('/product_details/{id}', $controller_path . '\Pages\productController@product_details');
