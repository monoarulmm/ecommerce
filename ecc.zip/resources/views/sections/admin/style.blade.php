

  <!-- Core CSS -->
  <link rel="stylesheet" href="assets/Admin/vendor/css/core.css" class="template-customizer-core-css" />
  <link rel="stylesheet" href="assets/Admin/vendor/css/theme-default.css" class="template-customizer-theme-css" />
  <link rel="stylesheet" href="assets/Admin/css/demo.css" />

  <!-- Vendors CSS -->
  <link rel="stylesheet" href="assets/Admin/vendor/libs/perfect-scrollbar/perfect-scrollbar.css" />

  <link rel="stylesheet" href="assets/Admin/vendor/libs/apex-charts/apex-charts.css" />

  <!-- Page CSS -->

  <script src="assets/Admin/vendor/js/helpers.js"></script>
  <script src="assets/Admin/js/config.js"></script>
