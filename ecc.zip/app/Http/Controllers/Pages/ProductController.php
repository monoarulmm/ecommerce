<?php

namespace App\Http\Controllers\Pages;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\File;
use App\Models\Product;
use App\Models\Category;
use App\Models\Shop;
class ProductController extends Controller
{
    public function product_page(){

        $user=Auth::user();
        $userid=$user->id;

        $categories =Category::all();
        
        $products =Product::Where('user_id','=',$userid)->get();
        $shops =Shop::Where('user_id','=',$userid)->get();
    
        return view('content.admin.pages.product.product_pages',compact('products','categories','shops'));
    }
    
    public function add_product(Request $request)
    {

        $request->validate([
            
                 
            'title' => 'string|required',
            'category' => 'string|required',
            'shop' => 'string|required',
            'product' => 'string|required',
            'stock_status' => 'string|required',
            'SKU' => 'string|required',
            'featured' => 'string|required',
            'quantity' => 'string|required',
            'return' => 'string|required',
            'regular_price' => 'string|required',
            'sale_price' => 'string|required',
            'sale_percent' => 'string|required',
            'description' => 'string|required',
            'image' => 'image|file|required|max:5120',
            'images' => 'image|file|required|max:5120',
         
            
         ],
         
         
         [
            
            'title.string ' => 'title Mustbe a string ',
            'title.required ' => 'title Mustbe a required ',
            
            'categpry.string ' => 'category Mustbe a string ',
            'category.required ' => 'category Mustbe a required ',

            'featured.string ' => 'featured Mustbe a string ',
            'featured.required ' => 'featured Mustbe a required ',
            

            'product.string ' => 'product Mustbe a string ',
            'product.required ' => 'product Mustbe a required ',

            'return.string ' => 'return Mustbe a string ',
            'return.required ' => 'return Mustbe a required ',

            'SKU.string ' => 'SKU Mustbe a string ',
            'SKU.required ' => 'SKU Mustbe a required ',

            'sale_percent.string ' => 'sale_percent Mustbe a string ',
            'sale_percent.required ' => 'sale_percent Mustbe a required ',

            'sale_price.string ' => 'sale_price Mustbe a string ',
            'sale_price.required ' => 'sale_price Mustbe a required ',

            'shop.string ' => 'shop Mustbe a string ',
            'shop.required ' => 'shop Mustbe a required ',

            'quantity.string ' => 'quantity Mustbe a string ',
            'quantity.required ' => 'quantity Mustbe a required ',

            'regular_price.string ' => 'regular Mustbe a string ',
            'regular_price.required ' => 'regular Mustbe a required ',

            'stock_status.string ' => 'stock_status Mustbe a string ',
            'stock_status.required ' => 'stock_status Mustbe a required ',
            
            'description.string ' => 'description Mustbe a string ',
            'description.required ' => 'description Mustbe a required ',
    
            'image.file' => 'file must be type of file',
            'image.image' => 'file must be image',
            'image.required' => 'you must choose a file',
            'image.size' => 'max file size id 10024KB',

            'images.file' => 'file must be type of file',
            'images.image' => 'file must be image',
            'images.required' => 'you must choose a file',
            'image.size' => 'max file size id 10024KB',
            
        
                   
             ]
         );
        

        $user=Auth()->user();
        $userid=$user->id;
        $name=$user->name;
        $email=$user->email;

    
         // image file name
         $file_name = time() . Str::upper(Str::random(16)) . '.' . $request->image->extension();
         // move the  image
         $request->image->move(public_path('storage/product'), $file_name);

         // image file name
         $file_name2 = time() . Str::upper(Str::random(16)) . '.' . $request->image->extension();
         // move the  image
         $request->images->move(public_path('storage/product'), $file_name2);
    
    
         $data = [
      
        'name' =>$name,
        'email' =>$email,
        'user_id' =>$userid,

    
        'title' =>$request->title,
        'category' =>$request->category,
        'shop' =>$request->category,
        'description' =>$request->description,
        'product' =>$request->product,
        'stock_status' =>$request->availability,
        'featured' =>$request->feature,
        'quantity' =>$request->quantity,
        'return' =>$request->return,
        'SKU' =>$request->price,
        'regular_price' =>$request->price,
        'sale_price' =>$request->discount_price,
        'sale_percent' =>$request->discount_price,

        'image' =>$file_name,
        'images' =>$file_name2,
        
         ];
      

     
      
      
      product::create($data);
    

      return redirect()->back()->with('message','product-added successfully');
    }
    
    


    
    public function delete_product($id)
    {

        $product=product::find($id);


        $image_path =public_path('storage/product/image/'.$product->image);
        if(file_exists($image_path))
        {
            unlink($image_path);
        }
        
        
        $image_path =public_path('storage/product/images/'.$product->images);
        if(file_exists($image_path))
        {
            unlink($image_path);
        }
        
        
        $product->delete();

        return redirect()->back()->with('message','product deleted successfully');
            
        }
        
        
        
        public function update_product($id)
        {
    

        
        $product=product::find($id);

        $user=Auth::user();
        $userid=$user->id;

        $categories =Category::Where('user_id','=',$userid)->get();
        
        $product =product::Where('user_id','=',$userid)->get();


            return view('content.admin.pages.product.product_edit', compact('product','categories','product'));
                
            }
            
            

            public function update_product_confirm(Request $request,  $id)
            {
                $request->validate([
            
                 
            'title' => 'string|required',
            'location' => 'string|required',
            'product' => 'string|required',
            'product' => 'string|required',
            'description' => 'string|required',
            'image' => 'image|file|required|max:10240',
    
            
         ],
         
         
         [
            
            'title.string ' => 'title Mustbe a string ',
            'title.required ' => 'title Mustbe a required ',
            
            'location.string ' => 'location Mustbe a string ',
            'location.required ' => 'location Mustbe a required ',
            
            'product.string ' => 'product Mustbe a string ',
            'product.required ' => 'product Mustbe a required ',

            'product.string ' => 'product Mustbe a string ',
            'product.required ' => 'product Mustbe a required ',
            
            'description.string ' => 'description Mustbe a string ',
            'description.required ' => 'description Mustbe a required ',
    
            'image.file' => 'file must be type of file',
            'image.image' => 'file must be image',
            'image.required' => 'you must choose a file',
            'image.size' => 'max file size id 10240KB',
            
        
                   
             ]
         );
                $product=product::find($id);
                
                $product->product =$request->product;
                $product->product =$request->product;
                $product->title =$request->title;
                $product->description =$request->description;
                $product->location =$request->location;

                $image=$request->image;
                if($image)
                {
                    $image_name = time() . '.' . $image->getClientOriginalExtension();
                    $request->image->move('storage/product',$image_name);
        
            
                    $product->image=$image_name;
                }

                $product->save();
         
                
                return redirect()->back()->with('message','product updated successfully');
      
              
            }

    
    
            public function show_product(){
        
                $product = product::all();
                return view('content.admin.pages.product.product_list',compact('product'));
            }
              

            public function my_product(){
    
    
                $user=Auth::user();
                $userid=$user->id;
                $product =product::Where('user_id','=',$userid)->get();
                
                
                return view('content.admin.pages.product.my_product',compact('product'));
            }
            


                 
            public function product_details($id){ 


                   $product=product::find($id);

                return view('content.users.pages.product_details',compact('product'));
              }
             
}
