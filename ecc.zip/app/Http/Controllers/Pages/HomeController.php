<?php

namespace App\Http\Controllers\Pages;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
Use App\Models\Category;
Use App\Models\Product;
Use App\Models\Shop;

class HomeController extends Controller
{
    public function index(){
        return view('content.users.home');
    }

    
    public function admindashboard(){
        return view('content.admin.dashboard');
    }
    
    public function product_all(){

        $products = Product::all();
        $categories = Category::all();

        return view('content.users.pages.product_all',compact('products','categories'));
    }
   


    public function tablecontent(){

        $categories = category::all();
        $shops = Shop::all();

        return view('content.admin.tablecontent',compact('categories','shops'));



    }


}
    