<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Cviebrock\EloquentSluggable\Sluggable;

class Product extends Model
{
    use HasFactory;
    protected $fillable = [
        
        'name' ,
        'email',
        'user_id',

        'title',
        'category',
        'shop',
        'SKU',
        'product',
        'stock',
        'featured',
        'quantity',
        'return',
        'regular_price',
        'sale_price',
        'sale_percent',
        'description',
        'image',
        'images',
        
   
        ];
      
        protected $table = 'products';
                   
 
 



    public function Sluggable():array
    {
        return[
            'slug'=>
            [
                'source'=> 'product'
            ]
        ];
    }

}
