<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/
$controller_path = 'App\Http\Controllers';

Route::get('/', function () {
    return view('welcome');
});


Route::get('/test', function () {
    return view('content.users.main');
});

Route::middleware([
    'auth:sanctum',
    config('jetstream.auth_session'),
    'verified'
])->group(function () {
    Route::get('/dashboard', function () {
        return view('dashboard');
    })->name('dashboard');
});

Route::get('/', $controller_path . '\Pages\HomeController@index');
Route::get('/admindashboard', $controller_path . '\Pages\HomeController@admindashboard')->name('admin.dashboard');

// category
Route::get('/category', $controller_path . '\Pages\CategoryController@category_page');
Route::post('/add_category', $controller_path . '\Pages\CategoryController@add_category');
Route::get('/delete_category/{id}',$controller_path . '\Pages\CategoryController@delete_category');
Route::get('/update_category/{id}',$controller_path . '\Pages\CategoryController@update_category');
Route::post('/update_category_confirm/{id}',$controller_path . '\Pages\CategoryController@update_category_confirm');
Route::get('/category_list',$controller_path . '\Pages\CategoryController@show_category');

// adminpages
Route::get('/admin/tablecontent', $controller_path . '\Pages\HomeController@tablecontent');


// Shop
Route::get('/shop', $controller_path . '\Pages\ShopController@Shop_page');
Route::post('/add_shop', $controller_path . '\Pages\ShopController@add_Shop');
Route::get('/delete_shop/{id}',$controller_path . '\Pages\ShopController@delete_shop');
Route::get('/update_shop/{id}',$controller_path . '\Pages\ShopController@update_shop');
Route::post('/update_shop_confirm/{id}',$controller_path . '\Pages\ShopController@update_shop_confirm');
Route::get('/shop_details/{id}', $controller_path . '\Pages\shopController@shop_details');



// product
Route::get('/product', $controller_path . '\Pages\productController@product_page');
Route::post('/add_product', $controller_path . '\Pages\productController@add_product');
Route::get('/delete_product/{id}',$controller_path . '\Pages\productController@delete_product');
Route::get('/update_product/{id}',$controller_path . '\Pages\productController@update_product');
Route::post('/update_product_confirm/{id}',$controller_path . '\Pages\productController@update_product_confirm');
Route::get('/product_details/{id}', $controller_path . '\Pages\productController@product_details');



Route::get('/user/product', $controller_path . '\Pages\HomeController@product_all');