

<div id="header" class="header header-style-1">
    <div class="container-fluid">
        <div class="row">
            <div class="topbar-menu-area">
                <div class="container">
                    <div class="topbar-menu left-menu">
                        <ul>
                            <li class="menu-item">
                                <a title="Hotline: (+123) 456 789" href="#"><span
                                        class="icon label-before fa fa-mobile "></span>Hotline: (+123) 456 789</a>
                            </li>
                        </ul>
                    </div>
                    <div class="topbar-menu right-menu">
                        <ul>
                            <li class="menu-item lang-menu menu-item-has-children parent">
                                <a title="English" href="#"><span class="img label-before"><img
                                            src="assets/images/lang-en.png" alt="lang-en"></span>English<i
                                        class="fa fa-angle-down" aria-hidden="true"></i></a>
                                <ul class="submenu lang">
                                    <li class="menu-item"><a title="hungary" href="#"><span
                                                class="img label-before"><img src="assets/images/lang-hun.png"
                                                    alt="lang-hun"></span>Hungary</a></li>
                                    <li class="menu-item"><a title="german" href="#"><span
                                                class="img label-before"><img src="assets/images/lang-ger.png"
                                                    alt="lang-ger"></span>German</a></li>
                                    <li class="menu-item"><a title="french" href="#"><span
                                                class="img label-before"><img src="assets/images/lang-fra.png"
                                                    alt="lang-fre"></span>French</a></li>
                                    <li class="menu-item"><a title="canada" href="#"><span
                                                class="img label-before"><img src="assets/images/lang-can.png"
                                                    alt="lang-can"></span>Canada</a></li>
                                </ul>
                            </li>




                            <?php if(Route::has('login')): ?>
                                <?php if(auth()->guard()->check()): ?>
                                    <?php if(Auth::user()->utype === 'ADM'): ?>
                                        <li class="menu-item menu-item-has-children parent">
                                            <a title="My Account" href="#">My Account(<?php echo e(Auth::user()->name); ?>)<i
                                                    class="fa fa-angle-down" aria-hidden="true"></i></a>
                                            <ul class="submenu curency">

                                                <li class="menu-item">
                                                    <a title="Dashboard" href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a>
                                                </li>



                                                <li class="menu-item">
                                                    <a title="My Profile" href="<?php echo e(route('profile.show')); ?>">My Profile</a>
                                                </li>



                                                <li class="menu-item">

                                                    <a
                                                        href="<?php echo e(route('logout')); ?>"onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Logout</a>

                                                </li>

                                                <form id="logout-form" method="POST" action="<?php echo e(route('logout')); ?>">
                                                    <?php echo csrf_field(); ?>
                                                </form>

                                            </ul>
                                        </li>
                                    <?php else: ?>
                                        <li class="menu-item menu-item-has-children parent">
                                            <a title="My Account" href="#">My Account(<?php echo e(Auth::user()->name); ?>)<i
                                                    class="fa fa-angle-down" aria-hidden="true"></i></a>
                                            <ul class="submenu curency">

                                                


                                                <li class="menu-item">
                                                    <a title="My Profile" href="<?php echo e(route('profile.show')); ?>">My Profile</a>
                                                </li>

                                                <li class="menu-item">

                                                    <a href="<?php echo e(route('logout')); ?>"
                                                        onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Logout</a>

                                                </li>

                                                <form id="logout-form" method="POST" action="<?php echo e(route('logout')); ?>">
                                                    <?php echo csrf_field(); ?>
                                                </form>


                                            </ul>
                                        </li>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <li class="menu-item"><a title="Register or Login" href="<?php echo e(route('login')); ?>">Login</a>
                                    </li>
                                    <li class="menu-item "><a title="Register or Login"
                                            href="<?php echo e(route('register')); ?>">Register</a></li>
                                <?php endif; ?>
                                <?php endif; ?>
                            </ul>

                        </div>
                    </div>
                </div>

                <div class="container">
                    <div class="mid-section main-info-area">
                        <div class="wrap-search center-section">
                            <div class="wrap-search-form">
                                <form action="#" id="form-search-top" name="form-search-top">
                                    <input type="text" name="search" value="" placeholder="Search here...">
                                    <button form="form-search-top" type="button"><i class="fa fa-search"
                                            aria-hidden="true"></i></button>
                                  
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php /**PATH C:\Users\monoa\Desktop\dinajmart\resources\views/sections/header.blade.php ENDPATH**/ ?>