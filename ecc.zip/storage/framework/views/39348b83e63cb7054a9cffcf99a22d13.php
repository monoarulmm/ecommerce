<?php $__env->startSection('title', 'category_pages'); ?>


<?php $__env->startSection('content'); ?>
    <main class="w-full flex-grow p-6">
        <h1 class="w-full text-3xl text-black pb-6"> Categories</h1>



        <?php if(session()->has('message')): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('message')); ?>

            </div>
        <?php endif; ?>



        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <div class="flex flex-wrap">
            <div class="w-full lg:w-1/2 my-6 pr-0 lg:pr-2">
                <p class="text-xl pb-6 flex items-center">
                    <i class="fas fa-list mr-3"></i> Categories Form
                </p>
                <div class="leading-loose">
                    <form action="<?php echo e(url('add_category')); ?>" method="POST" enctype="multipart/form-data"><?php echo csrf_field(); ?>
                        <div class="mt-3">
                            <label class="block text-sm text-gray-600" for="name">Add Categories</label>
                            <input class="w-full px-5 py-1 text-gray-700 bg-gray-200 rounded" name="title" type="text"
                                required="" placeholder="Your Category">

                            <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-denger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mt-2">
                            <label class="block text-sm text-gray-600" for="email">Category Image</label>
                            <input class="w-full px-5  py-4 text-gray-700 bg-gray-200 rounded" name="image" type="file"
                                required="">
                        </div>
                        
                        <div class="mt-6">

                            <input type="submit" value="Submit" class="btn-submit">
                            <input type="reset" value="Reset" class="btn-cancel">



                        </div>
                    </form>
                </div>
            </div>


            <div class="w-full lg:w-1/2 mt-6 pl-0 lg:pl-2">
                <p class="text-xl pb-3 flex items-center">
                    <i class="fas fa-list mr-3"></i> Table Example
                </p>
                <div class="bg-white overflow-auto">
                    <table class="min-w-full leading-normal">
                        <thead>
                            <tr>
                                <th
                                    class="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                                    Categories
                                </th>

                                <th
                                    class="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                                    Action
                                </th>

                            </tr>
                        </thead>
                        <tbody>

                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                                        <div class="flex items-center">
                                            <div class="flex-shrink-0 w-10 h-10">
                                                <img class="w-full h-full rounded-full"
                                                    src="/storage/category/<?php echo e($category->image); ?>" alt="image">"

                                            </div>
                                            <div class="ml-3">
                                                <p class="text-gray-900 whitespace-no-wrap">
                                                    <?php echo e($category->title); ?>

                                                </p>
                                            </div>
                                        </div>
                                    </td>

                                    <td class="px-10 py-5 border-b border-gray-200 bg-white text-sm">
                                        <div class="flex items-center gap-8">
                                            <div class=" w-10 h-10">

                                                <a class="btn-redirect" href="<?php echo e(url('update_category', $category->id)); ?>">
                                                    Edit</a>
                                            </div>
                                            <div class="ml-3">

                                                <a class="btn-delete" href="<?php echo e(url('delete_category', $category->id)); ?>">
                                                    X</a>
                                            </div>
                                        </div>
                                    </td>



                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </tbody>
                    </table>
                </div>
            </div>


        </div>

    </main>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\monoa\Desktop\tailwindcss\resources\views/content/admin/pages/categories/category_pages.blade.php ENDPATH**/ ?>