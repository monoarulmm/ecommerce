<?php $__env->startSection('title', 'dashboard'); ?>


<?php $__env->startSection('content'); ?>


<h1 class="text-center mt-10">admin</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\monoa\Desktop\dinajmart\resources\views/content/admin/dashboard.blade.php ENDPATH**/ ?>