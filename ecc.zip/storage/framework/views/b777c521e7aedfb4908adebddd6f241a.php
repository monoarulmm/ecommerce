<?php $__env->startSection('title', 'update_cetagory'); ?>
<base href="/public">

<?php $__env->startSection('content'); ?>


    <div class="content-wrapper">
        <div class="container-xxl flex-grow-1 container-p-y">

            <form action="<?php echo e(url('update_category_confirm', $category->id)); ?>" method="POST"><?php echo csrf_field(); ?>

                <?php if(session()->has('message')): ?>
                <div class="alert alert-success">
                    <?php echo e(session()->get('message')); ?>

                </div>
            <?php endif; ?>



            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">
                    Category</span>Update</h4>

            <div class="row">
                <div class="col-md-12">
                    <div class="card mb-4 ">
                        <div class="card-body">
                            <div class="mt-3">
                                <label class="form-label">Name_Of_Category</label>
                                <input type="text" class="form-control" name="category" value="<?php echo e($category->category); ?>"">
                                <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-denger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="mt-3">
                                <input type="submit" value="Submit" class=" btn btn-primary">
                                <input type="reset" value="Reset" class=" btn btn-gray">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            </form>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\monoa\Desktop\dinajmart\resources\views/content/admin/pages/categories/category_edit.blade.php ENDPATH**/ ?>