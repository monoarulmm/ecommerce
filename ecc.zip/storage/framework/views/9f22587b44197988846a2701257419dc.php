<?php $__env->startSection('title', 'cetagory'); ?>


<?php $__env->startSection('content'); ?>

    <div class="content-wrapper">
        <!-- Content -->
        <div class="container-xxl flex-grow-1 container-p-y">
            <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Tables /</span> Basic Tables</h4>

            <!-- Basic Bootstrap Table -->
            <div class="card">
                <h5 class="card-header">Table Basic</h5>
                <div class="table-responsive text-nowrap">

                    <table class="table">
                        <thead>
                            <tr>
                                <th>product Name</th>
                                <th>Owner Name</th>
                                <th>product Image Name</th>
                                <th>Update</th>
                                <th>Remove</th>

                            </tr>
                        </thead>

                        <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tbody class="table-border-bottom-0">
                                <tr>
                                    <td>
                                        <h4><?php echo e($product->product); ?></h4>
                                    </td>
                         
                                    <td>
                                        <h4><?php echo e($product->owner); ?></h4>
                                    </td>
                         
                                  
                                
                                        <td>
                                            <img style="width:50px;" src="/storage/product/image<?php echo e($product->image); ?>"
                                                alt="product_image">
                                        </td>

                                    <td>
                                        <a class="dropdown-item" href="<?php echo e(url('update_product', $product->id)); ?>"><i
                                                class="bx bx-edit-alt me-2"></i>
                                            Edit</a>
                                    </td>

                                    <td>
                                        <a onclick="return confirm('Are You sure to Delete this product')" class="dropdown-item" href="<?php echo e(url('delete_product', $product->id)); ?>"><i
                                                class="bx bx-trash me-2"></i>
                                            Delete</a>
                                    </td>


                                  
                                </tr>

                            </tbody>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </table>

                </div>
            </div>
            <!--/ Basic Bootstrap Table -->

            <div class="content-backdrop fade"></div>
        </div>
        <!-- Content wrapper -->
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\monoa\Desktop\dinajmart\resources\views/content/admin/pages/product/product_list.blade.php ENDPATH**/ ?>